
public class divisible {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s=0,i;
		for(i=10;i<=30;i++)
		{
			if(i%3==0)
				s+=i;
				
		}
		System.out.print("Sum is : "+s);
		
	}

}
