
public class Account {
	 int no;
	 float bal,rate;
	 
	 
	 public String get_acc_details()
	 {
		 String str= "Account no. : "+ no + "\n" + " Account Balance : "+ bal +"\n" + "Interest Rate : "+ rate;
		 return str;
	 }
	 
	 public float cal_Interest(float amt)
	 {
		 return amt*rate/100;
	 }
}
