
public class StudentAvgMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentAvg s1 = new StudentAvg();
		StudentAvg s2 = new StudentAvg();
		s1.name="Sajal";
		s1.m1=99;
		s1.m2=95;
		s2.name="Rahul";
		s2.m1=90;
		s2.m2=98;
		if(s1.calavg()>s2.calavg())
			s1.display();
		else
			s2.display();
		
		
		
	}

}
