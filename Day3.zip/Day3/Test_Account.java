
public class Test_Account {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sb_account s1=new sb_account();
		s1.no=1234;
		s1.bal=10000;
		s1.rate=8;
		System.out.println(s1.get_acc_details());
		s1.deposit(5000);
		System.out.println(s1.get_acc_details());
		s1.withdraw(8000);
		System.out.println(s1.get_acc_details());
		
		
	}

}
