
public class Zoo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d = new Dog();
		d.id=1233;
		d.gender="male";
		d.exsistence="Exists";
		d.no_of_legs=4;
		d.bark();
		d.run();
		d.display_details();
	}

}
