
public class ExampleGetter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account_with_getter a = new Account_with_getter();
		a.setAcc_no(1234);
		a.setAcc_bal(560000);
		System.out.println(a.getAcc_no());
		System.out.println(a.getAcc_bal());
	}

}
