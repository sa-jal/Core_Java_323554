
public class SBI extends Bank{
	public float get_roi()
	{
		r_o_i=6.5f;
		return r_o_i;
	}
	

}
